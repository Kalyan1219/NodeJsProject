const express = require('express');
const router = express.Router();

let slots = [
  { time: "2:00 PM", available: 4, bookings: [] },
  { time: "3:00 PM", available: 4, bookings: [] },
  { time: "4:00 PM", available: 4, bookings: [] }
];

router.get('/', (req, res) => {
  res.render('index', { slots });
});

router.post('/book', (req, res) => {
  const { time, name, email } = req.body;
  const slot = slots.find(s => s.time === time);

  if (slot && slot.available > 0) {
    slot.bookings.push({ name, email });
    slot.available -= 1;
  }

  res.redirect('/');
});

router.post('/cancel', (req, res) => {
  const { time, name } = req.body;
  const slot = slots.find(s => s.time === time);

  if (slot) {
    slot.bookings = slot.bookings.filter(booking => booking.name !== name);
    slot.available += 1;
  }

  res.redirect('/');
});

module.exports = router;
